If you are reporting an issue that involves any JSX (e.g.
<div>{`${example}`}</div>), PLEASE PLEASE PLEASE make sure you have properly
setup and are sourcing this plugin https://github.com/mxw/vim-jsx

WE DO NOT support JSX automatically, you need another plugin to add get this
functionality.

If applicable, include a snippet of code that we can easily copy and paste that
replicates your bug.

Make sure the bug still exists if you disable all other javascript plugins
except the one noted above, mxw/vim-jsx
